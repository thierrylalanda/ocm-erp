import ConfirmEmail from "@/components/Authentication/ConfirmEmail";

export default function Page() {
  return (
    <>
      <ConfirmEmail />
    </>
  );
}
