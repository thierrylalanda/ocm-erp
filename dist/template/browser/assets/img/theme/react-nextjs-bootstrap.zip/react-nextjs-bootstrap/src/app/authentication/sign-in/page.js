import SignInForm from "@/components/Authentication/SignInForm";

export default function Page() {
  return (
    <>
      <SignInForm />
    </>
  );
}
